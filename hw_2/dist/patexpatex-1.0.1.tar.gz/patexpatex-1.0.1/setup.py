from setuptools import setup, find_packages
from glob import glob

setup(
    name="patexpatex",
    version="1.0.1",
    author="Mark Baushenko",
    author_email="m.baushenko@gmail.com",
    description="test desc",
    license="MIT",
    url="https://github.com/e0xextazy/python-advanced",
    packages=find_packages(),
    install_requires=[],
    keywords="key word",
)